<?php

// You can find the keys here : https://dev.twitter.com/

return array(
	'API_URL'             => 'api.twitter.com',
	'API_VERSION'         => '1.1',
	'USE_SSL'             => true,

	'CONSUMER_KEY'        => 'koK6L21LBgG3WPtRdr1C105O6',
	'CONSUMER_SECRET'     => '2nsYfUK5FvHgXWBkdK6OlwmUjd0rxNbxYXzXzgUI8Gf22BrBou',
	'ACCESS_TOKEN'        => '61370071-n8JTxgxmcvVCiSfS8wfxMllYv33ZbxgbvfSA9aDWf',
	'ACCESS_TOKEN_SECRET' => 'yIESfpwOtWk9zUlyDkT9iFoxyw9rTppvfOAYJ1Fq01eNg',
);